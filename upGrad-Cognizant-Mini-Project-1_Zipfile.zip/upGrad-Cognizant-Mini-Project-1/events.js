
const $logoutBtn = $("#logoutBtn");
if ($logoutBtn.length) {
    $logoutBtn.on("click", function () {
        localStorage.removeItem("loggedIn");
        window.location.replace("login.html");
    });
}

//Adding Cards Dynamically

const $eventForm = $("#eventsForm");

if ($eventForm.length) {
    $eventForm.on("submit", function (e) {
        e.preventDefault();

        let eventId = $("#eventId").val();
        let eventName = $("#eventName").val();
        let eventCategory = $("#eventCategory").val();
        let eventDate = $("#eventDate").val();
        let eventTime = $("#eventTime").val();

        let event = {
            id: eventId,
            name: eventName,
            category: eventCategory,
            date: eventDate,
            time: eventTime
        };

        let events = JSON.parse(localStorage.getItem("events")) || [];
        events.push(event);

        localStorage.setItem("events", JSON.stringify(events));

        alert("Event Added Successfully");

        $eventForm[0].reset();
        renderAdminEvents();
    });
}

const $adminEventsRow = $("#adminEventsRow");
const $searchInput = $("#searchInput");

function renderAdminEvents(eventsToRender) {
    if (!$adminEventsRow.length) return;

    $adminEventsRow.empty();

    if (!eventsToRender) {
        eventsToRender = JSON.parse(localStorage.getItem("events")) || [];
    }

    if (eventsToRender.length === 0) {
        $adminEventsRow.html(`<div class="col-12 text-center mt-4"><p>No events found.</p></div>`);
        return;
    }

    eventsToRender.forEach(function (event) {
        let $card = $("<div>").addClass("col-12 col-md-6 col-lg-3 mb-3 text-start");

        $card.html(`
        <div class="card-container h-100 d-flex flex-column">
            <div class="d-flex">
                <p class="event-name"><i class="bi bi-tag"></i>${event.category}</p>
                <p class="event-number bg-dark ms-auto">${event.id}</p>
            </div>
            <h1>${event.name}</h1>
            <p><i class="bi bi-calendar icon-1"></i>${event.date}</p>
            <p><i class="bi bi-clock icon-1"></i>${event.time}</p>
            <p><i class="bi bi-camera-video icon-1"></i>Virtual Event</p>
            
            <div class="mt-auto pt-3">
                <button class="btn btn-outline-primary w-100 delete-event-btn" data-event-id="${event.id}">Delete Event</button>
            </div>
        </div>
        `);
        $adminEventsRow.append($card);
    });

    $(".delete-event-btn").on("click", function () {
        deleteAdminEvent($(this).attr("data-event-id"));
    });
}

// Search filtering
function triggerSearch() {
    let searchTerm = $searchInput.val().toLowerCase();
    let allEvents = JSON.parse(localStorage.getItem("events")) || [];
    let filteredEvents = allEvents.filter(event => 
        event.name.toLowerCase().includes(searchTerm) || 
        event.category.toLowerCase().includes(searchTerm) ||
        event.id.toLowerCase().includes(searchTerm)
    );
    renderAdminEvents(filteredEvents);
}

if ($searchInput.length) {
    $searchInput.on("input", triggerSearch);
}

window.deleteAdminEvent = function (eventId) {
    if (confirm("Are you sure you want to delete this event?")) {
        let events = JSON.parse(localStorage.getItem("events")) || [];
        events = events.filter(e => e.id !== eventId);
        localStorage.setItem("events", JSON.stringify(events));
        renderAdminEvents();
    }
};

if ($adminEventsRow.length) {
    renderAdminEvents();
}

