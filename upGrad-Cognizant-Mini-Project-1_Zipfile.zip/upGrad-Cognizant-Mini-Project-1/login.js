// Login Authentication
const $loginForm = $("#loginForm");

if ($loginForm.length) {
    $loginForm.on("submit", loginUser);
}

function loginUser(e) {
    e.preventDefault();
    let loginEmail = $("#loginEmail").val();
    let loginPassword = $("#loginPassword").val();
    
    if (loginEmail === "admin@upgrad.com" && loginPassword === "12345") {
        alert("Login Successful");
        localStorage.setItem("loggedIn", "true");
        window.location.href = "events.html";
    } else {
        alert("Invalid Credentials");
    }
}
