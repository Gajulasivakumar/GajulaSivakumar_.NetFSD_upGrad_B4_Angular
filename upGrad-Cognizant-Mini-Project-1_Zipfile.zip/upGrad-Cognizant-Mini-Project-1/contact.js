// contact us feedback message send

const $contactForm = $("#contactForm");

if ($contactForm.length) {
    $contactForm.on("submit", function(e) {
        e.preventDefault();
        alert("Thank you for contacting us! We will get back to you soon.");
        $contactForm[0].reset();
    });
}