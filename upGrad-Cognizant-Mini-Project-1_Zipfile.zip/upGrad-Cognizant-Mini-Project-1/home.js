const $eventsRow = $("#eventsRow");

// 1. Define default events
const defaultEvents = [
    { id: "EVT001", name: "Intro to AI & ML", category: "Tech & Innovations", date: "2026-03-14", time: "10:30" },
    { id: "EVT002", name: ".NET Full Stack", category: "Tech & Innovations", date: "2026-03-14", time: "11:30" },
    { id: "EVT003", name: "Generative AI", category: "Tech & Innovations", date: "2026-03-14", time: "13:30" },
    { id: "EVT004", name: "Intro to LLM's", category: "Tech & Innovations", date: "2026-03-14", time: "14:30" }
];

// 2. Initialize localStorage if empty
if (!localStorage.getItem("events")) {
    localStorage.setItem("events", JSON.stringify(defaultEvents));
}

// 3. Render function for public home page (no delete button)
function renderEvents(eventsToRender) {
    if (!$eventsRow.length) return;
    
    $eventsRow.empty(); 
    
    if (eventsToRender.length === 0) {
        $eventsRow.html(`<div class="col-12 text-center mt-4"><p>No events found.</p></div>`);
        return;
    }

    eventsToRender.forEach(function(event) {
        let $card = $("<div>").addClass("col-12 col-md-6 col-lg-3 mb-4");
        
        $card.html(`
        <div class="card-container h-100 d-flex flex-column">
            <div class="d-flex">
                <p class="event-name"><i class="bi bi-tag"></i>${event.category}</p>
                <p class="event-number bg-dark ms-auto">${event.id}</p>
            </div>
            <h1>${event.name}</h1>
            <p><i class="bi bi-calendar icon-1"></i>${event.date}</p>
            <p><i class="bi bi-clock icon-1"></i>${event.time}</p>
            <p><i class="bi bi-camera-video icon-1"></i>Virtual Event</p>
            
            <div class="mt-auto pt-3">
                <a href="registration.html?eventId=${event.id}" class="btn btn-primary w-100 mb-2">Register Now</a>
            </div>
        </div>
        `);
        $eventsRow.append($card);
    });
}

// Initial render
let allEvents = JSON.parse(localStorage.getItem("events")) || [];
renderEvents(allEvents);

