$(document).ready(function() {
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get("eventId");
    
    if (eventId) {
        let events = JSON.parse(localStorage.getItem("events")) || [];
        let selectedEvent = events.find(e => e.id === eventId);
        
        if (selectedEvent) {
            let $infoCard = $("#eventInfoCard");
            if ($infoCard.length) $infoCard.addClass("d-block");
            
            let $nameEl = $("#regEventName");
            if ($nameEl.length) $nameEl.text(selectedEvent.name);
            
            let $catEl = $("#regEventCategory");
            if ($catEl.length) $catEl.text(selectedEvent.category);
            
            let $dateEl = $("#regEventDate");
            if ($dateEl.length) $dateEl.text(selectedEvent.date);
            
            let $timeEl = $("#regEventTime");
            if ($timeEl.length) $timeEl.text(selectedEvent.time);
            
            let $idEl = $("#regEventId");
            if ($idEl.length) $idEl.text(selectedEvent.id);
            
            let $titleEl = $("#pageTitle");
            if ($titleEl.length) $titleEl.text("Register for " + selectedEvent.name);
        }
    }
});

const $registerForm = $("#registerForm");

if ($registerForm.length) {
    $registerForm.on("submit", function(e){
        e.preventDefault();

        let $message = $("#registrationMessage");

        $message.text("Registration successful! All the best for the event.");
        window.alert("Registration Successful!");
        $message.addClass("text-success");
        $registerForm[0].reset();
    });
}